extern uint64_t *const aarch64_sp_ptr;
extern uint32_t *const arm_sp_ptr;
