static long alpha_r0;
static long alpha_a3;
#define ARCH_PC_PEEK_ADDR REG_PC
