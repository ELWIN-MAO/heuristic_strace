extern long *const arm_sp_ptr;
