static long cris_r10;
#define ARCH_PC_PEEK_ADDR (4 * PT_IRP)
