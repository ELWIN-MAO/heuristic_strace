#include "crisv10/arch_regs.c"
#define ARCH_PC_PEEK_ADDR (4 * PT_ERP)
