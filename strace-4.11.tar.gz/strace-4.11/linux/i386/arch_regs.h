extern long *const i386_esp_ptr;
