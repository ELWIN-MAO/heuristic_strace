long
getrval2(struct tcb *tcp)
{
	return ia64_regs.gr[9];
}
