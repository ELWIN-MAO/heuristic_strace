static long m68k_d0;
#define ARCH_PC_PEEK_ADDR (4 * PT_PC)
