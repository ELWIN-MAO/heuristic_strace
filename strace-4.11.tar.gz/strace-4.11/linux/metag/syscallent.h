#include "32/syscallent.h"
[244] = { },
[245] = { 2,	0,	SEN(printargs),	"metag_setglobalbit"	},
[246] = { 1,	0,	SEN(printargs),	"metag_set_fpu_flags"	},
[247] = { 1,	0,	SEN(printargs),	"metag_set_tls"		},
[248] = { 0,	NF,	SEN(printargs),	"metag_get_tls"		},
[249 ... 259] = { },
