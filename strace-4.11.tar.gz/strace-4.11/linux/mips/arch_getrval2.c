long
getrval2(struct tcb *tcp)
{
	return mips_regs.uregs[3];
}
