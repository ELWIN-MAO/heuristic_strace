#define ARCH_mmap mmap_pgoff
#include "32/syscallent.h"
[244] = {4,    0,	SEN(cacheflush), "cacheflush"},
[245 ... 259] = { },
