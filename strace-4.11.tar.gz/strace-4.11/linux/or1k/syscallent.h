#define ARCH_mmap mmap_pgoff
#include "32/syscallent.h"
[244] = { 3,	NF,	SEN(or1k_atomic),	"or1k_atomic"	},
[245 ... 259] = { },
