#include "../errnoent.h"
[ 58] = "EDEADLOCK",
