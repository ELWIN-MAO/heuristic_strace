#include "powerpc/arch_regs.c"
#define ARCH_PC_REG ppc_regs.nip
