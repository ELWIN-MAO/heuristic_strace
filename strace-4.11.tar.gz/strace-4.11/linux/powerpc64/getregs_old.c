#include "powerpc/getregs_old.c"
