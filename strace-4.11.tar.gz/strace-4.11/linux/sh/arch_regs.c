static long sh_r0;
#define ARCH_PC_PEEK_ADDR (4 * REG_PC)
