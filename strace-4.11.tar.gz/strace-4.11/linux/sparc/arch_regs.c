struct pt_regs sparc_regs; /* not static */
#define ARCH_REGS_FOR_GETREGS sparc_regs
#define ARCH_PC_REG sparc_regs.pc
