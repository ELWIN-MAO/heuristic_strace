#include "sparc/arch_regs.c"
#define ARCH_PC_REG sparc_regs.tpc
