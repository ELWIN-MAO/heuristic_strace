#include "sparc/arch_sigreturn.c"
