#include "sparc/get_syscall_args.c"
