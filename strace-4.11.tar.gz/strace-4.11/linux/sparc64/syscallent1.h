#define sys_mmap_4koff sys_mmap_pgoff
#include "../sparc/syscallent.h"
#undef sys_mmap_4koff
