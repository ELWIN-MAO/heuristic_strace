/* tilegx32/tilepro */
#include "errnoent.h"
