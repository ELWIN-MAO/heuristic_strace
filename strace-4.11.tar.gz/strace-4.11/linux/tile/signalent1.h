/* tilegx32/tilepro */
#include "signalent.h"
