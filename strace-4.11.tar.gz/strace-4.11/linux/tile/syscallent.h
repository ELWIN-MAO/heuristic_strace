#include "64/syscallent.h"
[244] = { 1,	0,	SEN(printargs),	"cmpxchg_badaddr"	},
[245] = { 3,	0,	SEN(printargs),	"cacheflush"		},
[246 ... 259] = { },
