{ sizeof(struct user),	"sizeof(struct user)" },
