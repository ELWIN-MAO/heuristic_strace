/* Our second set comes from the i386 files.  */

#include "../i386/syscallent.h"
