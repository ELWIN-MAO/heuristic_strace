static long xtensa_a2;
#define ARCH_PC_PEEK_ADDR REG_PC
