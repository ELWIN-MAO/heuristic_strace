#undef MPERS_PRINTER_NAME
#define MPERS_PRINTER_NAME(printer_name) printer_name

#include "native_printer_decls.h"
