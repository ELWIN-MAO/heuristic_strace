extern void printsiginfo(const siginfo_t *, bool);
