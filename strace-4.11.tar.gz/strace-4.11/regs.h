#include <sys/user.h>

#ifdef HAVE_SYS_REG_H
# include <sys/reg.h>
#endif

#include "arch_regs.h"
