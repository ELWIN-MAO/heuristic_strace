int f1(int i);

int f0(int i)
{
	return f1(i) - i;
}
