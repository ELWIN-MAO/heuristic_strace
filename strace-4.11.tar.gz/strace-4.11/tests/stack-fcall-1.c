int f2(int i);

int f1(int i)
{
	return f2(i) + i;
}
