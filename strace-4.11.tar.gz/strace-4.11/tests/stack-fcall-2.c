int f3(int i);

int f2(int i)
{
	return f3(i) - i;
}
