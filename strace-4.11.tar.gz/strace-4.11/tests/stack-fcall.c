int f0(int i);

int main(int argc, char** argv)
{
	f0(argc);
	return 0;
}
